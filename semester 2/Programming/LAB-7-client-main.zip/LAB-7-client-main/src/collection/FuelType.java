package collection;

import java.io.Serializable;

/**
 * types of fuel
 */
public enum FuelType implements Serializable {
    GASOLINE,
    DIESEL,
    MANPOWER,
    PLASMA,
    ANTIMATTER;
}
