package depricated;

import java.io.*;
import java.net.*;

public class Transfer {

    DatagramSocket socket;
    InetAddress address;
/*
    public Transfer() throws SocketException, UnknownHostException {
        socket = new DatagramSocket();
        socket.setSoTimeout(1000);
        address = InetAddress.getByName("localhost");
    }


    public void send(Request request) throws IOException {
        byte[] byteArray = request.toByteArray();
        DatagramPacket packet = new DatagramPacket(byteArray, byteArray.length, address, 4445);
        socket.send(packet);
    }
*/
    /**
     * return message from server or information about unavailability of the sever
     *
     * @return message from server or information about unavailability of the sever
     */
    /*public String receive() throws IOException, ClassNotFoundException {
        return Response.fromByteArray(receiveByteArray(socket)).getMessage();
    }*/

    /*public static byte[] receiveByteArray(DatagramSocket socket) throws IOException {
        byte[] byteBuffer = new byte[2048];
        DatagramPacket packet = new DatagramPacket(byteBuffer, byteBuffer.length);
        socket.receive(packet);
        return byteBuffer;
    }*/

}
