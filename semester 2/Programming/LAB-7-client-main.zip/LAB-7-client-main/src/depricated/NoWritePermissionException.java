package depricated;
/**
 * floor is made of floor
 */
public class NoWritePermissionException extends Exception{
}
