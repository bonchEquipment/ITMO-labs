package depricated;
/**
 * floor is made of floor
 */
public class NoElementWithSuchIdException extends RuntimeException {
}
