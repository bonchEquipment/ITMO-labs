package depricated;
/**
 * floor is made of floor
 */
public class NoArgumentsInUserCommandException extends Exception {
}
