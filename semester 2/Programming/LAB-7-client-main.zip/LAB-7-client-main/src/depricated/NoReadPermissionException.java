package depricated;
/**
 * floor is made of floor
 */
public class NoReadPermissionException extends Exception {
}
