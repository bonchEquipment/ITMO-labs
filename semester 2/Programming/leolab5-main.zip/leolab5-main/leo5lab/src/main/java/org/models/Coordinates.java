package org.models;

public class Coordinates {
    private Float x; //Поле не может быть null
    private long y; //Значение поля должно быть больше -494
}