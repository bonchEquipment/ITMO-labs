package org.commands;

public enum ArgumentType {
    PRIMITIVE,
    ELEMENT
}
