package org.models;

public enum EventType {
    FOOTBALL,
    BASEBALL,
    BASKETBALL,
    OPERA,
    THEATRE_PERFORMANCE;
}
