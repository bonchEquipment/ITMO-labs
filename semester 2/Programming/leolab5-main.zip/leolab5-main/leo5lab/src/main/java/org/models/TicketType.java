package org.models;

public enum TicketType {
    VIP,
    USUAL,
    BUDGETARY,
    CHEAP;
}