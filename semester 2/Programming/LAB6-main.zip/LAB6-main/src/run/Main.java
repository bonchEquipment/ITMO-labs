package run;

import utility.Client;
import utility.FinalRunnable;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {

        FinalRunnable finalRunnable = new FinalRunnable();
        finalRunnable.run();

    }

}
