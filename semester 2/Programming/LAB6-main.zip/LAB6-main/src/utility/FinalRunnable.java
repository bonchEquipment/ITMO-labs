package utility;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class FinalRunnable {


    private AbstractOutputSystem outputSystem = new ConsoleOutputSystem();
    Scanner scanner = new Scanner(System.in);
    Client client = new Client();

    public void run() throws IOException, ClassNotFoundException {


        while (scanner.hasNext()){
            String userCommand = scanner.nextLine();

            if (userCommand.toLowerCase().equals("exit")){
                System.exit(0);
            }

            if (!client.isAValidCommand(userCommand)){
                outputSystem.showMessage("no such command \"" + userCommand +
                        "\" type \"help\" to see commands available");
                continue;
            }

            Commmand commmand = client.sendCommand(userCommand);

            DatagramSocket socket = new DatagramSocket();
            InetAddress address = InetAddress.getByName("localhost");
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(byteArrayOutputStream);

            oos.writeObject(commmand);
            oos.flush();
            byte[] buf = byteArrayOutputStream.toByteArray();


            DatagramPacket packet = new DatagramPacket(buf, buf.length, address, 4445);
            socket.send(packet);

            socket.setSoTimeout(1000);
            buf = new byte[2048];
            packet = new DatagramPacket(buf, buf.length);
            try{
                socket.receive(packet);
            } catch (SocketTimeoutException e){
                outputSystem.showMessage("server is temporarily unavailable, try later");
                continue;
            }



            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(buf);
            ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);

            Message message =  (Message) objectInputStream.readObject();


           // System.out.println(new String(packet.getData()));
            outputSystem.showMessage(message.getMessage());


        }
    }


}
