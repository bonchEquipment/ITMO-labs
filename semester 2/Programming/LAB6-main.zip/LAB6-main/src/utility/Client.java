package utility;

import collection.Vehicle;
import collection.VehicleType;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Client {


    protected String userCommand;
    private AbstractOutputSystem outputSystem = new ConsoleOutputSystem();


    public void run() throws InterruptedException {
        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNext()) {
            userCommand = scanner.nextLine();
            if (isAValidCommand(userCommand)) {
                sendCommand(userCommand);
              //  outputSystem.showMessage(Receiver.receive());

            } else {
                outputSystem.showMessage("no such command \"" + userCommand +
                        "\" type \"help\" to see commands available");
            }
        }
    }


    public Commmand sendCommand(String stringCommand) {
        String[] words = stringCommand.trim().toLowerCase().split(" ");
        if (words[0].equals("add")) {
            Vehicle vehicle = new Vehicle(0, System.out, new Scanner(System.in));
            Commmand command = new Commmand("add", vehicle);
            return command;

        } else if (words[0].equals("update")) {
            Vehicle vehicle = new Vehicle(0, System.out, new Scanner(System.in));
            Commmand command = new Commmand("add", words[1], vehicle);
            return command;
        } else if (Commands.getCommandsWithArguments().contains(words[0])) {
            Commmand command = new Commmand(words[0], words[1]);
            return command;
        }
        Commmand command = new Commmand(words[0]);
        return command;

    }

    public boolean isAValidCommand(String usersString) {
        String[] words = usersString.trim().toLowerCase().split(" ");
        String validatedString = words[0];
        for (String command : Commands.getAllCommands()) {
            if (command.equals(validatedString)) {
                if (Commands.getCommandsWithArguments().contains(validatedString)) {
                    if (words.length == 2) {
                        return isCommandHaveValidArgument(words[0], words[1]);
                    } else {
                        return false;
                    }
                }
                if (words.length != 1) {
                    return false;
                }
                return true;
            }
        }
        return false;
    }


    private boolean isCommandHaveValidArgument(String command, String argument) {
        if (Commands.getCommandsWithNumberArgument().contains(command)) {
            try {
                Integer.parseInt(argument);
                return true;
            } catch (NumberFormatException e) {
                return false;
            }
        } else if (command.equals("count_by_type") || command.equals("print_field_descending_fuel_type")) {
            try {
                VehicleType.valueOf(argument.toUpperCase());
                return true;
            } catch (IllegalArgumentException e) {
                return false;
            }
        }
        try {
            BufferedReader reader = new BufferedReader(new FileReader(argument));
            reader.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }


}



