package utility;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketTimeoutException;

public class Receiver {

    private static final int SERVICE_PORT = 50003;

    public static String receive() {

        try {
            DatagramSocket clientSocket = new DatagramSocket();
            clientSocket.setSoTimeout(1000);
            byte[] byteBuffer = new byte[2048];
            DatagramPacket datagramPacket = new DatagramPacket(byteBuffer, byteBuffer.length);
            clientSocket.receive(datagramPacket);
            System.out.println("I recieved something");
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteBuffer);
            ObjectInputStream oos = new ObjectInputStream(byteArrayInputStream);

             Message message =  (Message) oos.readObject();


            clientSocket.close();
            return message.getMessage();


        } catch (SocketTimeoutException e){
                 return "the server is temporarily unavailable, try later";
        } catch (Exception e) {
            e.printStackTrace();
            return "some unexpected exception unexpectedly accrue";
        }

    }
}
