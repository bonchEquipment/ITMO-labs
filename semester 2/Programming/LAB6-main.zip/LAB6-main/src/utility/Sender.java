package utility;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Sender {

    private static final int SERVICE_PORT = 50003;

    public static String send(Commmand command) {

        try {
            DatagramSocket clientSocket = new DatagramSocket();
            InetAddress IPAddress = InetAddress.getByName("localhost");
            byte[] byteBuffer = new byte[2048];
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(byteArrayOutputStream);

            oos.writeObject(command);
            oos.flush();
            byte[] sendingDataBuffer = byteArrayOutputStream.toByteArray();
            DatagramPacket outputPacket = new DatagramPacket(sendingDataBuffer, sendingDataBuffer.length, IPAddress, SERVICE_PORT);

            clientSocket.send(outputPacket);

            outputPacket = new DatagramPacket(sendingDataBuffer, sendingDataBuffer.length);
            clientSocket.receive(outputPacket);
            clientSocket.close();
            return new String(outputPacket.getData());

        } catch (IOException e) {
             e.printStackTrace();
        }
        return "nothing good";
    }



}
