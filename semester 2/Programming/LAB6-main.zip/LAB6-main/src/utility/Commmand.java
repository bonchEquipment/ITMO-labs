package utility;

import collection.Vehicle;

import java.io.Serializable;

public class Commmand implements Serializable {

    private Vehicle vehicle;
    private String argument;
    private String name;

    public Commmand(String name, String argument, Vehicle vehicle  ) {
        this.vehicle = vehicle;
        this.argument = argument;
        this.name = name;
    }

    public Commmand(String name, Vehicle vehicle) {
        this.vehicle = vehicle;
        this.name = name;
    }

    public Commmand(String name, String argument) {
        this.argument = argument;
        this.name = name;
    }

    public Commmand(String name) {
        this.name = name;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public String getArgument() {
        return argument;
    }

    public String getName() {
        return name;
    }
}
