package exceptions;


/**
 * floor is made of floor
 */
public class NoElementWithSuchIdException extends Exception {
}
