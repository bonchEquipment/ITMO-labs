package collection;

import java.io.Serializable;

/**
 * some types of vehicle
 */
public enum VehicleType implements Serializable {
    MOTORCYCLE,
    CHOPPER,
    SPACESHIP;
}
