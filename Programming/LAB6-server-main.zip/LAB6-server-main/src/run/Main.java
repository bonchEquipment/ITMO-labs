package run;

import utility.*;

import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        FinalRunnable  finalRunnable = new FinalRunnable();
        finalRunnable.run();


//        Scanner scanner = new Scanner(System.in);
//        while (true){
//            String s = scanner.nextLine();
//            if (s.equals("save")){
//                System.out.println(finalRunnable.getCommandSave().execute());
//            }
//        }
//
   }
}

