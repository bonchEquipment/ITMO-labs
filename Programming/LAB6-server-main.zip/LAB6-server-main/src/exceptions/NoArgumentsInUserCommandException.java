package exceptions;
/**
 * floor is made of floor
 */
public class NoArgumentsInUserCommandException extends Exception {
}
