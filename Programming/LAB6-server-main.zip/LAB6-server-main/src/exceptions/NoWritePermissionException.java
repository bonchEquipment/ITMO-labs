package exceptions;
/**
 * floor is made of floor
 */
public class NoWritePermissionException extends Exception{
}
