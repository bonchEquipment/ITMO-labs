package utility;

import commands.Command;
import commands.CommandSave;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class FinalRunnable extends Thread {


    DatagramSocket socket = new DatagramSocket(4445);
    Server server = new Server();

    public FinalRunnable() throws SocketException {
    }


    public void run() {
        try{
        while (true) {
            byte[] buf = new byte[2048];
            DatagramPacket packet = new DatagramPacket(buf, buf.length);
            socket.receive(packet);
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(buf);
            ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);

            Commmand command = (Commmand) objectInputStream.readObject();
            InetAddress address = packet.getAddress();
            int port = packet.getPort();
            buf = new byte[2048];
            String m = server.executeCommand(command.getName(), command.getArgument(), command.getVehicle());
            ////
            Message message = new Message(m);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);

            objectOutputStream.writeObject(message);
            objectOutputStream.flush();
            buf = byteArrayOutputStream.toByteArray();


            // buf = m.getBytes();
            packet = new DatagramPacket(buf, buf.length, address, port);
            socket.send(packet);


        }

    }catch (Exception e){

        }




    }

    public CommandSave getCommandSave(){
        for (Command command: server.commandsList){
            if (command.getName().equals("save")){
                return (CommandSave) command;
            }
        }
        return null;
    }

}