package exceptions;
/**
 * floor is made of floor
 */
public class NoReadPermissionException extends Exception {
}
