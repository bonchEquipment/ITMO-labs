package utility;

import comands.Command;

import java.util.ArrayList;
import java.util.Collection;

public class StorageForCommands {

    private Collection<Command> commandList = new ArrayList<Command>();

}
