package utility;

/**
 * class for displaying information
 */
public class OutputSystem {

    /**
     *
     * @param message that needed to be displayed
     */
    public void showMessage (String message){
        System.out.println(message);
    }
}
