package collection;

/**
 * types of fuel
 */
public enum FuelType {
    GASOLINE,
    DIESEL,
    MANPOWER,
    PLASMA,
    ANTIMATTER;
}
