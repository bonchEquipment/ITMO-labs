package collection;

/**
 * some types of vehicle
 */
public enum VehicleType {
    MOTORCYCLE,
    CHOPPER,
    SPACESHIP;
}
