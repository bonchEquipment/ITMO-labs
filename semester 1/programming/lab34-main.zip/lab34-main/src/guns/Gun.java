package guns;

public interface Gun {

    void shoot(Target target);
}
