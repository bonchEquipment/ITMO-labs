package guns;

/**
 * Target is literally anything you can aim in
 */
public interface Target {

    void takeDamage();
}
