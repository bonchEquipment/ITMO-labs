package clothes;

public enum Affiliation {
    POLICE,
    BANDIT,
    ORDINARY,
    BANK;
}
