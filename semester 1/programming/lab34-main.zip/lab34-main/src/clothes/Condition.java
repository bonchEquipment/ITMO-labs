package clothes;

public enum Condition {
    INTACT,
    DAMAGED,
    TORN,
}
