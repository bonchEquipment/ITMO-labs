package run;

public class Main {

    public static void main(String[] args) {
        Story storyAboutRobbery = new Story();
        storyAboutRobbery.tellStory();

    }
}
