package persons;

public enum Location {
    BANK,
    STREET,
    TWIN_TOWERS,
    BANDIT_LAIR,
    POLICE_STATION;
}