package persons;

public enum State {
    HEALTHY,
    INJURED,
    DEAD;
}
