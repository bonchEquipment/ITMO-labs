package pack;

public interface AbleToSee {
    void lookAround();
}
