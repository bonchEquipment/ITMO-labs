package pack;

public class HaveNothingToReadException extends RuntimeException {

    public HaveNothingToReadException(String message){
        super(message);
    }
}
