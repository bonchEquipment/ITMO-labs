package pack;

public class OutsideThePlanetException extends Exception{

 public OutsideThePlanetException(String message){
     super(message);
 }
}
