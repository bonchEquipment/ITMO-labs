
const xButtons = document.querySelectorAll(".button-x");

const yLim1itationLabel = document.querySelector("#y-limitation-label");
const rLim1itationLabel = document.querySelector("#r-limitation-label");

const yIn1put = document.querySelector("#CoordinateY");
const rIn1put = document.querySelector("#CoordinateR");



const targ1etDot = document.querySelector("#target-dot");
const gr1aph = document.querySelector(".left-part-of-the-content");

const rightP1artOfTheContent = document.querySelector(".right-part-of-the-content");


setTimeout(setListener, 100);



function setListener(){
    const body = document.querySelector(".body");
    body.onclick = htmlIsClicked;
}




function getRLabel(){
    const parent = document.querySelector("#r-value-section");
    return parent.lastChild.previousSibling;
}

function getYLabel(){
    const parent = document.querySelector("#y-value-section");
    return parent.lastChild.previousSibling;
}

function yLabelChange(){
    const yLabel = getYLabel();
    if (yLabel.value.length > 16){
        yLabel.value = yLabel.value.substring(0, 16);
    }
    console.log(yLabel.value);
}

function rLabelChange() {
    const rLabel = getRLabel();
    if (rLabel.value.length > 16){
        rLabel.value = rLabel.value.substring(0, 16);
    }
    console.log(rLabel.value);
}


function clear(){
    getYLabel().value = "";
    getRLabel().value = "";
}




/*
graph
 */
// graph.onclick =
     function htmlIsClicked(event){

    const target = this.getBoundingClientRect();
    let xCoordinate = event.clientX - target.left - 32;
    const yCoordinate = event.clientY - target.top - 96;
    if (xCoordinate < 0 || xCoordinate > 424  || yCoordinate < 0 || yCoordinate > 424) return ;
    console.log ("x: " + xCoordinate + " y: " + yCoordinate);
         if (!isRValueCorrect()){
             alert("R is incorrect");
             return;
            // alert("значение R не указанно ");//а как правильно писать
         }

    let width = 424;
    let height = 424;
    const pixelsInOneRadiusX = (width + 3) / 2.5;
    const pixelsInOneRadiusY = (height + 3) / 2.5;
    const numberOfRadiusInX = (xCoordinate - width/2) / pixelsInOneRadiusX;
    const numberOfRadiusInY = - (yCoordinate - height/2) / pixelsInOneRadiusY;


    const yValue = (numberOfRadiusInY * getRLabel().value).toFixed(4);
    const xValue = Number((numberOfRadiusInX*getRLabel().value).toFixed(4));

    console.log ("xValue: " + xValue + " yValue: " + yValue);

    sendHTTPAimRequest(xValue, yValue, getRLabel().value);

}


function getFakeXLabel(){
    let form = document.querySelector(".invisible").firstChild.nextSibling;
    return form.firstChild.nextSibling.nextSibling.nextSibling;

}



function getFakeYLabel(){
    return  getFakeXLabel().nextSibling;
}

function getFakeRLabel(){
    return  getFakeYLabel().nextSibling;
}

function getFakeSendButton(){
    return  getFakeRLabel().nextSibling;

}

function isRValueCorrect() {
    const number = (Number(getRLabel().value))
    if (getRLabel().value.length === 0) {
        return false;
    } else if (isNaN(number)) {
        return false;
    } else if (number == 0){
        return false;
    } else return !(number >= 5 || number <= 2);
}


function moveTargetDotByRealCoordinates(realX, realY){
    if (realX === undefined || realX.length === 0 || isNaN(realX) || realY === undefined || getChosenX === undefined) {
        targetDot.setAttribute('r', '0');
        return;
    }
    targetDot.setAttribute('r', '4');
    targetDot.setAttribute('cx', realX.toString());
    targetDot.setAttribute('cy', realY.toString());
}

function moveTargetByCoordinates(x, y, r) {
    let width = Number(graph.getAttribute("width"));
    let height = Number(graph.getAttribute("height"));
    const pixelsInOneRadiusX = (width + 3) / 2.5;
    const pixelsInOneRadiusY = (height + 3) / 2.5;
    let xCoordinate = width / 2 + pixelsInOneRadiusX * (x / r);
    let yCoordinate = height / 2 - pixelsInOneRadiusY * (y / r);

    moveTargetDotByRealCoordinates(xCoordinate, yCoordinate)
}

function moveTargetDot() {
    let chosenX = getChosenX();
    let chosenY = getY();
    let chosenR = getR();
    moveTargetByCoordinates(chosenX, chosenY, chosenR);
}

/*
Y
 */
function yHadBeenEntered() {
    if (!isYValueCorrect()){
        playYHintAnimation();
    }
    moveTargetDot();
}


function isYValueCorrect() {
    const number = (Number(yInput.value))
    if (yInput.value.length === 0) {
        return false;
    } else if (isNaN(number)) {
        return false;
    }  else return !(number >= 5 || number <= -5);
}

function isYTooLong() {
    let value = yInput.value;
    return value.length > 18;
}

function getY() {
    return yInput.value;
}

function playYHintAnimation() {
    yLimitationLabel.title = "not_transparent";
    setTimeout(() => yLimitationLabel.title = "transparent", 6000);
}

function playYTooLong() {
    let number =  yInput.value;
    yInput.value = number.substring(0, 17);
    sendButtonPress();
}

/*
R
 */
function rHadBeenEntered() {
    if (!isRValueCorrect()){
        playRHintAnimation();
    }
    moveTargetDot();
}




function isRTooLong() {
    return rInput.value.length > 18;
}

function getR() {
    return rInput.value;
}

function playRHintAnimation() {
    rLimitationLabel.title = "not_transparent";
    setTimeout(() => rLimitationLabel.title = "transparent", 6000);
}

function playRTooLong() {
    let number =  rInput.value;
    rInput.value = number.substring(0, 17);
    sendButtonPress();
}


/*
X
 */
function isXSelected() {

    return !(getChosenX() === undefined);
}

function XButtonIsClicked(number) {
    deleteClassButtonActive();
    for (let button of xButtons) {
        if (Number(button.value) === number) {
            button.classList.add("button-y-active");
        }
    }
    moveTargetDot();
}


function getChosenX() {
    for (let button of xButtons) {
        if (button.classList.contains("button-y-active")) {
            return button.value;
        }
    }
}

function playXSectionAnimation() {
    for (let button of xButtons) {
        button.classList.add("button-y-highlighted");
        setTimeout(() => button.classList.remove("button-y-highlighted"), 2500);
    }
}

function deleteClassButtonActive() {
    for (let button of xButtons) {
        button.classList.remove("button-y-active")
    }
}



/*
buttons
*/
function sendButtonPress() {
    if (isYTooLong()){
        playYTooLong();
        return;
    }
    if (isRTooLong()){
        playRTooLong();
        return;
    }
    if (isYValueCorrect() && isRValueCorrect() && isXSelected()) {
        sendHTTPAimRequest(getChosenX(), getY(), getR());
    } else {
        if (xValue === null) playXSectionAnimation();
        if (!isYValueCorrect()) playYHintAnimation();
        if (!isRValueCorrect()) playRHintAnimation();
    }
}

function clearButtonPress() {
    clearResultTable();
    deleteClassButtonActive();
    yInput.value = "";
    rInput.value = "";
}

/*
result table
 */
function clearResultTable() {
    sendHTTPCleanRequest();
}

/*
http request
 */

function sendHTTPAimRequest(x, y, r){
    getFakeXLabel().value = x;
    getFakeYLabel().value = y;
    getFakeRLabel().value = r;
    getFakeSendButton().click();
}

function sendHTTPCleanRequest(){
    const requestURL = "/WEB-LAB2-1.0-SNAPSHOT/controller";
    const httpRequest = new XMLHttpRequest();

    httpRequest.open("POST", requestURL);

    httpRequest.setRequestHeader("Content-Type", "application/json" );
    httpRequest.setRequestHeader("charset", "UTF-8" );

    httpRequest.onload = () => {
        rightPartOfTheContent.innerHTML = httpRequest.responseText
    }

    const body = {
        requestType: "clear table"
    };

    httpRequest.send(JSON.stringify(body));
}


