function clock() {
    const clock_label = document.querySelector("#clock_label");
    let date = new Date();
    let hours = (date.getHours() < 10) ? "0" + date.getHours() : date.getHours();
    let minutes = (date.getMinutes() < 10) ? "0" + date.getMinutes() : date.getMinutes();
    let seconds = (date.getSeconds() < 10) ? "0" + date.getSeconds() : date.getSeconds();
    clock_label.innerHTML = (hours + ":" + minutes + ":" + seconds);
}

setTimeout(clock, 0);
setInterval(clock, 11000);