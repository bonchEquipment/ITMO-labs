package webapp;


import org.hibernate.Session;
import org.hibernate.Transaction;

import javax.annotation.ManagedBean;

import javax.faces.bean.SessionScoped;
import javax.persistence.*;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@ManagedBean
@SessionScoped
public class Bean implements Serializable {

    private static final double HEIGHT_OF_AREA = 424;
    private static final double WIDTH_OF_AREA = 424;

    private List<Result> resultList;
    private ArrayList<GraphicDot> graphicDots;
    private double radius;
    private double x;
    private double y;

    public Bean() {
        connect();
    }

    private void connect(){
        Session hibernateSession = HibernateUtil.getSession();

    }

    private void updateResultList(){
        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        resultList = (List<Result>) session.createQuery("FROM Result").getResultList();
        transaction.commit();
        session.close();

    }


    public void clear(){
        setResultList(new ArrayList<>());
        x = 0;
        y = 0;
        radius = 0;


            Session session = getSession();
            Transaction transaction = session.beginTransaction();
            session.createQuery("DELETE FROM Result").executeUpdate();
            transaction.commit();
        session.close();

    }

    public void addDot(){
        String str_result = isHit(x, y, radius) ? "попадание" : "мимо";
        Result result = new Result(x, y, radius, str_result, (new SimpleDateFormat("HH:mm:ss")).format(new Date()));

        Session session = getSession();
        Transaction transaction = session.beginTransaction();
        session.save(result);
        transaction.commit();
        session.close();
        return;
    }


    private double countRealX(double x, double r){
        double pixelsInOneRadiusX = (WIDTH_OF_AREA + 0) / 2.5;
        return WIDTH_OF_AREA / 2 + pixelsInOneRadiusX * (x / r);

    }

    private double countRealY(double y, double r){
        double pixelsInOneRadiusY = (HEIGHT_OF_AREA + 0) / 2.5;
        return HEIGHT_OF_AREA / 2 - pixelsInOneRadiusY * (y / r);
    }

    private boolean isHit(double x, double y, double r){
        if (x > 0 && y == 0){
            return x < r/2;
        } else if (x > 0 && y>0){
            return y < r - 2 * x;
        } else if (x == 0 && y > 0) {
            return y < r;
        } else if (x < 0 && y > 0) {
            return (Math.sqrt(x * x + y * y) < r);
        } else if (x > 0 && y < 0) {
            return (x < r && -y < r / 2);
        } else {
            return false;
        }
    }


    private ArrayList<GraphicDot> getGraphicDotsFromResults(List<Result> results){

        ArrayList<GraphicDot> graphicDots = new ArrayList<>();

        for (Result result: results){
            double realX = countRealX(result.getX_value(), radius);
            double realY = countRealY(result.getY_value(), radius);
            String color = isHit(result.getX_value(), result.getY_value(), getRadius()) ? "white" : "black";
            graphicDots.add(new GraphicDot(realX, realY, color));
        }
        return graphicDots;
    }

    private Session getSession(){
        return HibernateUtil.getSession();
    }

    public List<Result> getResultList() {
        if (resultList == null) { resultList = new ArrayList<>(); }
        updateResultList();
        return resultList;
    }

    public void setResultList(ArrayList<Result> resultList) {
        this.resultList = resultList;
    }

    public ArrayList<GraphicDot> getGraphicDots() {
        graphicDots = getGraphicDotsFromResults(getResultList());
        return graphicDots;
    }

    public void setGraphicDots(ArrayList<GraphicDot> graphicDots) {
        this.graphicDots = graphicDots;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }
}
